public class Project {
    public static void main(String[]args){
        newgame A = new newgame();
        A.fillArrayOfScores();
        A.askName();
        A.startGame();
    }
}
